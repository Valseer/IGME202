﻿using UnityEngine;
using System.Collections.Generic;

public class AgentManager : MonoBehaviour {
	public Transform psgModel;
	public Transform humanModel;
	public List<GameObject> Objs;
	public GameObject psg;
	private float maxX=200;
	private float maxZ=200;
	public Vector3 avgDirection= new Vector3(0,0,0);
	public Vector3 flockCenter= new Vector3(0,0,0);

	// Use this for initialization
	void Start () {
		SpawnAssets();
	}
	
	// Update is called once per frame
	void Update () {
		CheckAssets();
	}

	void SpawnAssets(){
		Transform tempPSG= (Transform) Instantiate(psgModel,RandSpawn(), new Quaternion(0f,0f,0f,0f));
		psg= tempPSG.gameObject;
		for(int i=0; i<4; i++){
			Transform tempHum = (Transform) Instantiate(humanModel,RandSpawn(),new Quaternion(0f,0f,0f,0f));
			tempHum.GetComponent<Flocker>().seekTarget=psg;
			tempHum.GetComponent<Flocker>().avoidTarget= psg;
			Objs.Add(tempHum.gameObject);
		}
	}

	Vector3 RandSpawn(){ 
		return new Vector3 (Random.Range (-maxX, maxX), 5f, Random.Range(-maxZ, maxZ));
	}

	void CheckAssets(){
		/*
			look at each human and calculate their forces
			apply each force to the human

			next look at the zombie have it seek the closest human

			finally if there is a human within 6units of the PSG respawn the PSG
		 */
		avgDirection= new Vector3(0,0,0);
		flockCenter= new Vector3(0,0,0);
		for(int i=0; i<Objs.Count;i++){
			Vector3 dist= Objs[i].transform.position -psg.transform.position;
			if(dist.magnitude<50f){
				psg.transform.position=RandSpawn();
			}
			avgDirection += Objs[i].transform.forward;
			flockCenter +=  Objs[i].transform.position;
		}
		avgDirection = avgDirection/Objs.Count;
		flockCenter = flockCenter/Objs.Count;
	}

	float CalcDist(Vector3 target, Vector3 seeker){
		return (((target.x-seeker.x)*(target.x-seeker.x))+((target.z-seeker.z)*(target.z-seeker.z)));
	}
	
	//standard bounding circle collision detection same as from Collision assignment.
	bool BoundingCircle( GameObject obj1, GameObject obj2){
		//Distance from the center x and y
		//if the square distance is greater than the radius square return true
		if(CalcDist(obj1.transform.position, obj2.transform.position)<= (125f)){
			return true;
		}
		//otherwise return false
		return false;
	}

}
